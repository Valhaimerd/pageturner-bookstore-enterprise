<x-app-layout>
    <x-slot name="header">
        <div class="catalog-header-card">
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight text-center">
                Book Catalog
            </h2>
            <p class="mt-1 text-sm text-ink-500 text-center">
                Browse available books by category and view their details.
            </p>
        </div>
    </x-slot>

    <div class="catalog-page-wrap space-y-6">
        <section class="store-toolbar catalog-toolbar-wrap">
            <div>
                <h3 class="store-toolbar-title">Find your next read</h3>
                <p class="store-toolbar-text">
                    Explore the collection and filter by category.
                </p>
            </div>

            <form method="GET" action="{{ route('books.index') }}" class="filter-form">
                <select name="category" class="filter-select">
                    <option value="">All Categories</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->slug }}" {{ $selectedCategory === $category->slug ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                    @endforeach
                </select>

                <button type="submit" class="nav-action-primary">
                    Filter
                </button>

                <a href="{{ route('books.index') }}" class="nav-action-secondary">
                    Reset
                </a>
            </form>
        </section>

        @if($books->count())
            <section class="catalog-grid">
                @foreach($books as $book)
                    <article class="book-card">
                        @if($book->cover_image)
                            <img
                                src="{{ asset('storage/' . $book->cover_image) }}"
                                alt="{{ $book->title }}"
                                class="book-card-media"
                            >
                        @else
                            <div class="book-card-placeholder">
                                No Image
                            </div>
                        @endif

                        <div class="book-card-body">
                            @if($book->category?->name)
                                <span class="book-category-pill">
                                    {{ $book->category->name }}
                                </span>
                            @endif

                            <h3 class="book-title">{{ $book->title }}</h3>
                            <p class="book-author">by {{ $book->author }}</p>

                            <p class="book-price">
                                ₱{{ number_format((float) $book->price, 2) }}
                            </p>

                            <p class="book-meta">
                                Stock: {{ $book->stock }}
                            </p>

                            <div class="mt-5">
                                <a href="{{ route('books.show', $book->slug) }}" class="nav-action-primary">
                                    View Details
                                </a>
                            </div>
                        </div>
                    </article>
                @endforeach
            </section>

            <div class="pt-2">
                {{ $books->links() }}
            </div>
        @else
            <div class="empty-state-card">
                <h3 class="empty-state-title">No books found</h3>
                <p class="empty-state-text">
                    Try changing the selected category or reset the filter.
                </p>
            </div>
        @endif
    </div>
</x-app-layout>
