<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn-danger-ui'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\components\danger-button.blade.php ENDPATH**/ ?>