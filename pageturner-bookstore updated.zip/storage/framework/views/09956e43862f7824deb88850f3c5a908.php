<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Audit Trail Export</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #1f2937; }
        h1 { font-size: 20px; margin-bottom: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 16px; }
        th, td { border: 1px solid #d1d5db; padding: 8px; vertical-align: top; }
        th { background: #f3f4f6; text-align: left; }
    </style>
</head>
<body>
    <h1>Audit Trail Export</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Event</th>
                <th>Model</th>
                <th>Values</th>
                <th>Context</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($audit->id); ?></td>
                    <td><?php echo e($audit->user?->name ?: 'System'); ?></td>
                    <td><?php echo e($audit->event); ?></td>
                    <td><?php echo e(class_basename((string) $audit->auditable_type)); ?> #<?php echo e($audit->auditable_id); ?></td>
                    <td>
                        <strong>Old:</strong> <?php echo e(json_encode($audit->old_values)); ?><br>
                        <strong>New:</strong> <?php echo e(json_encode($audit->new_values)); ?>

                    </td>
                    <td><?php echo e($audit->method ?: 'CLI'); ?> <?php echo e($audit->url ?: ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\admin\audits\pdf.blade.php ENDPATH**/ ?>