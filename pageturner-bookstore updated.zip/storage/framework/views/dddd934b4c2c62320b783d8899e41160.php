<footer class="site-footer">
    <div class="site-footer-inner">
        <div class="site-footer-grid">
            <div class="site-footer-brand">
                <span class="flex h-9 w-9 items-center justify-center rounded-2xl bg-white shadow-soft ring-1 ring-sage-100">
                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'h-5 w-5 fill-current text-brand-700']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5 w-5 fill-current text-brand-700']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                </span>

                <div>
                    <p class="site-footer-title">
                        Page<span class="brand-highlight">Turner</span>
                    </p>
                    <p class="site-footer-text">Modern bookstore experience</p>
                </div>
            </div>

            <div>
                <p class="site-footer-heading">Quick Links</p>
                <div class="site-footer-links mt-1">
                    <a href="<?php echo e(route('home')); ?>" class="site-footer-link">Home</a>
                    <a href="<?php echo e(route('books.index')); ?>" class="site-footer-link">Books</a>

                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>" class="site-footer-link">Login</a>
                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="site-footer-link">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('profile.edit')); ?>" class="site-footer-link">Profile</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="site-footer-bottom">
            <p>© <?php echo e(now()->year); ?> PageTurner</p>
            <p>Teal + sage UI</p>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\layouts\footer.blade.php ENDPATH**/ ?>