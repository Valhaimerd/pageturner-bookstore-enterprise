<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    My Orders
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    Review your order history, status, receipts, and totals.
                </p>
            </div>

            <a href="<?php echo e(route('books.index')); ?>" class="nav-action-primary">
                Shop Books
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if($orders->count()): ?>
        <section class="content-card">
                <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <h3 class="content-card-title">Order History</h3>
                        <p class="content-card-subtitle">
                            View all your orders and open their receipts anytime.
                        </p>
                    </div>

                    <form method="POST" action="<?php echo e(route('customer.exports.orders')); ?>" class="flex gap-2">
                        <?php echo csrf_field(); ?>
                        <button type="submit" name="format" value="csv" class="nav-action-secondary">Export CSV</button>
                        <button type="submit" name="format" value="xlsx" class="nav-action-secondary">Export XLSX</button>
                        <button type="submit" name="format" value="pdf" class="nav-action-primary">Export PDF</button>
                    </form>
                </div>

                <div class="mt-5 ui-table-wrap">
                    <table class="ui-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Receipt #</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Total</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $status = strtolower($order->status);
                                    $statusClass = match($status) {
                                        'pending' => 'status-pill status-pill-pending',
                                        'completed' => 'status-pill status-pill-completed',
                                        default => 'status-pill status-pill-default',
                                    };
                                ?>
                                <tr>
                                    <td class="font-semibold text-ink-900"><?php echo e($order->order_number); ?></td>
                                    <td><?php echo e($order->receipt_number ?: '—'); ?></td>
                                    <td><?php echo e($order->created_at->format('M d, Y')); ?></td>
                                    <td>
                                        <span class="<?php echo e($statusClass); ?>">
                                            <?php echo e(ucfirst($order->status)); ?>

                                        </span>
                                    </td>
                                    <td>₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></td>
                                    <td>
                                        <div class="flex flex-wrap gap-2">
                                            <a href="<?php echo e(route('orders.show', $order)); ?>" class="nav-action-primary">
                                                View
                                            </a>

                                            <a href="<?php echo e(route('orders.receipt', $order)); ?>" class="nav-action-secondary">
                                                Receipt
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-5">
                    <?php echo e($orders->links()); ?>

                </div>
            </section>
        <?php else: ?>
            <div class="empty-state-card">
                <h3 class="empty-state-title">No orders yet</h3>
                <p class="empty-state-text">
                    Your orders will appear here after checkout.
                </p>

                <div class="mt-5">
                    <a href="<?php echo e(route('books.index')); ?>" class="nav-action-primary">
                        Start Shopping
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\orders\index.blade.php ENDPATH**/ ?>