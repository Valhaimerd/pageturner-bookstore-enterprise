<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                Customer Dashboard
            </h2>
            <p class="mt-1 text-sm text-ink-500">
                Track your activity, orders, reviews, and spending in one place.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(auth()->user() && !auth()->user()->hasVerifiedEmail()): ?>
            <div class="soft-alert-warning">
                Your email is not verified yet. You must verify before checkout and reviews.
                <a class="ml-1 font-semibold underline" href="<?php echo e(route('verification.notice')); ?>">Verify now</a>
            </div>
        <?php endif; ?>

        <section class="dashboard-hero">
            <span class="dashboard-chip">Customer Summary</span>
            <h1 class="dashboard-title mt-4">
                Welcome, <?php echo e(auth()->user()->name); ?>.
            </h1>
            <p class="dashboard-subtitle">
                Here is your recent activity, order progress, total spending, and review history.
            </p>

            <div class="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <a href="<?php echo e(route('books.index')); ?>" class="nav-action-primary">
                    Browse Books
                </a>

                <a href="<?php echo e(route('cart.index')); ?>" class="nav-action-secondary">
                    View Cart
                </a>

                <a href="<?php echo e(route('orders.index')); ?>" class="nav-action-secondary">
                    My Orders
                </a>

                <a href="<?php echo e(route('profile.edit')); ?>" class="nav-action-secondary">
                    Edit Profile
                </a>

                <a href="<?php echo e(route('customer.exports.personal')); ?>" class="nav-action-secondary">
                    Export My Data
                </a>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-5">
            <div class="metric-card">
                <p class="metric-label">Total Orders</p>
                <p class="metric-value"><?php echo e($totalOrders); ?></p>
                <p class="metric-note">All orders placed</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Pending</p>
                <p class="metric-value"><?php echo e($pendingOrders); ?></p>
                <p class="metric-note">Orders in progress</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Completed</p>
                <p class="metric-value"><?php echo e($completedOrders); ?></p>
                <p class="metric-note">Finished purchases</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Total Spent</p>
                <p class="metric-value">₱<?php echo e(number_format((float) $totalSpent, 2)); ?></p>
                <p class="metric-note">Lifetime spending</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">My Reviews</p>
                <p class="metric-value"><?php echo e($totalReviews); ?></p>
                <p class="metric-note">Reviews submitted</p>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-5 lg:grid-cols-2">
            <a href="<?php echo e(route('books.index')); ?>" class="quick-link-card">
                <h3 class="quick-link-title">Explore the catalog</h3>
                <p class="quick-link-text">Browse available books and discover your next read.</p>
            </a>

            <a href="<?php echo e(route('orders.index')); ?>" class="quick-link-card">
                <h3 class="quick-link-title">Track your orders</h3>
                <p class="quick-link-text">Review order statuses, totals, and detailed purchase history.</p>
            </a>
        </section>

        <section class="grid grid-cols-1 gap-5 lg:grid-cols-3">
            <a href="<?php echo e(route('customer.exports.personal')); ?>" class="quick-link-card">
                <h3 class="quick-link-title">Download personal data</h3>
                <p class="quick-link-text">Export your profile, order, and review data as JSON.</p>
            </a>

            <form action="<?php echo e(route('customer.exports.orders')); ?>" method="POST" class="quick-link-card">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="format" value="pdf">
                <button type="submit" class="w-full text-left">
                    <h3 class="quick-link-title">Export order history</h3>
                    <p class="quick-link-text">Generate a PDF archive of your order history.</p>
                </button>
            </form>

            <a href="<?php echo e(route('customer.exports.reading')); ?>" class="quick-link-card">
                <h3 class="quick-link-title">Reading history</h3>
                <p class="quick-link-text">Export purchased books and submitted reviews.</p>
            </a>
        </section>

        <?php if($recentExports->count()): ?>
            <section class="content-card">
                <h3 class="content-card-title">Recent Data Exports</h3>
                <p class="content-card-subtitle">Completed generated files remain available for a limited time.</p>

                <div class="mt-5 ui-table-wrap">
                    <table class="ui-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Format</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>File</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentExports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $export): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(str_replace('_', ' ', ucfirst($export->type))); ?></td>
                                    <td><?php echo e(strtoupper($export->format)); ?></td>
                                    <td>
                                        <span class="status-pill <?php echo e($export->status === 'completed' ? 'status-pill-completed' : 'status-pill-default'); ?>">
                                            <?php echo e(ucfirst($export->status)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e(optional($export->created_at)->format('M d, Y h:i A')); ?></td>
                                    <td>
                                        <?php if($export->status === 'completed' && $export->path): ?>
                                            <a href="<?php echo e(route('exports.download', $export)); ?>" class="nav-action-secondary">Download</a>
                                        <?php else: ?>
                                            <span class="text-ink-400">Processing</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>
        <?php endif; ?>

        <section class="grid grid-cols-1 gap-6 xl:grid-cols-2">
            <div class="content-card">
                <h3 class="content-card-title">Recent Orders</h3>
                <p class="content-card-subtitle">Your latest purchases and current order statuses.</p>

                <div class="mt-5">
                    <?php if($recentOrders->count()): ?>
                        <div class="ui-table-wrap">
                            <table class="ui-table">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Status</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $status = strtolower($order->status);
                                            $statusClass = match($status) {
                                                'pending' => 'status-pill status-pill-pending',
                                                'completed' => 'status-pill status-pill-completed',
                                                default => 'status-pill status-pill-default',
                                            };
                                        ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('orders.show', $order)); ?>" class="font-semibold text-brand-700 hover:underline">
                                                    <?php echo e($order->order_number); ?>

                                                </a>
                                            </td>
                                            <td>
                                                <span class="<?php echo e($statusClass); ?>">
                                                    <?php echo e(ucfirst($order->status)); ?>

                                                </span>
                                            </td>
                                            <td>₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mt-5 text-sm text-ink-500">No orders yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="content-card">
                <h3 class="content-card-title">Recent Reviews</h3>
                <p class="content-card-subtitle">Your latest ratings and comments on books.</p>

                <div class="mt-5">
                    <?php if($recentReviews->count()): ?>
                        <div class="space-y-4">
                            <?php $__currentLoopData = $recentReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-2xl border border-sage-100 bg-sage-50 p-4">
                                    <p class="font-semibold text-ink-900"><?php echo e($review->book?->title); ?></p>
                                    <p class="mt-1 text-sm font-medium text-brand-700">Rating: <?php echo e($review->rating); ?>/5</p>
                                    <p class="mt-2 text-sm leading-6 text-ink-600"><?php echo e($review->comment ?: 'No comment.'); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-ink-500">No reviews yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views/customer/dashboard.blade.php ENDPATH**/ ?>