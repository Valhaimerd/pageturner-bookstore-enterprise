<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    Books
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    Manage catalog entries, stock, status, and cover images.
                </p>
            </div>

            <a href="<?php echo e(route('admin.books.create')); ?>" class="nav-action-primary">
                Add Book
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(session('success')): ?>
            <div class="soft-alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <section class="admin-panel">
            <?php if($books->count()): ?>
                <div class="ui-table-wrap">
                    <table class="ui-table">
                        <thead>
                            <tr>
                                <th>Cover</th>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Author</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <?php if($book->cover_image): ?>
                                            <img src="<?php echo e(asset('storage/' . $book->cover_image)); ?>"
                                                 alt="<?php echo e($book->title); ?>"
                                                 class="admin-table-thumb">
                                        <?php else: ?>
                                            <span class="admin-table-thumb-placeholder">No image</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="font-semibold text-ink-900"><?php echo e($book->title); ?></td>
                                    <td><?php echo e($book->category?->name); ?></td>
                                    <td><?php echo e($book->author); ?></td>
                                    <td>₱<?php echo e(number_format((float) $book->price, 2)); ?></td>
                                    <td><?php echo e($book->stock); ?></td>
                                    <td>
                                        <span class="<?php echo e(strtolower($book->status) === 'active' ? 'status-pill status-pill-completed' : 'status-pill status-pill-default'); ?>">
                                            <?php echo e(ucfirst($book->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="flex flex-wrap gap-2">
                                            <a href="<?php echo e(route('admin.books.edit', $book)); ?>" class="nav-action-secondary">
                                                Edit
                                            </a>

                                            <form action="<?php echo e(route('admin.books.destroy', $book)); ?>"
                                                  method="POST"
                                                  onsubmit="return confirm('Delete this book?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn-danger-ui">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-ink-500">No books found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-5">
                    <?php echo e($books->links()); ?>

                </div>
            <?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\admin\books\index.blade.php ENDPATH**/ ?>