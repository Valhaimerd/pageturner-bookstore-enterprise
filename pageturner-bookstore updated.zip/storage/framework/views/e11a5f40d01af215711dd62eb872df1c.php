<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                Data Management
            </h2>
            <p class="mt-1 text-sm text-ink-500">
                Run imports, exports, backups, and monitor audit and API activity from one place.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(session('success')): ?>
            <div class="soft-alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="soft-alert-danger">
                <ul class="space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <section class="admin-stat-grid">
            <div class="metric-card">
                <p class="metric-label">Database Size</p>
                <p class="metric-value"><?php echo e(number_format($systemHealth['database_size'] / 1048576, 2)); ?> MB</p>
                <p class="metric-note">Current sqlite footprint</p>
            </div>
            <div class="metric-card">
                <p class="metric-label">Storage Usage</p>
                <p class="metric-value"><?php echo e(number_format($systemHealth['storage_usage'] / 1048576, 2)); ?> MB</p>
                <p class="metric-note">Private app storage</p>
            </div>
            <div class="metric-card">
                <p class="metric-label">Pending Jobs</p>
                <p class="metric-value"><?php echo e($systemHealth['pending_jobs']); ?></p>
                <p class="metric-note">Queued work waiting to run</p>
            </div>
            <div class="metric-card">
                <p class="metric-label">Failed Jobs</p>
                <p class="metric-value"><?php echo e($systemHealth['failed_jobs']); ?></p>
                <p class="metric-note">Jobs that need review</p>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-6 xl:grid-cols-2">
            <div class="admin-panel space-y-5">
                <div>
                    <h3 class="admin-panel-title">Book Import</h3>
                    <p class="admin-panel-subtitle">Upload CSV/XLSX files using the assignment template and queued chunk processing.</p>
                </div>

                <div class="flex flex-wrap gap-3">
                    <a href="<?php echo e(route('admin.data.template.books')); ?>" class="nav-action-secondary">Download Template</a>
                </div>

                <form method="POST" action="<?php echo e(route('admin.data.imports.books')); ?>" enctype="multipart/form-data" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="form-label">Book File</label>
                        <input type="file" name="file" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label">Duplicate Handling</label>
                        <select name="duplicate_strategy" class="form-input">
                            <option value="skip">Skip duplicates</option>
                            <option value="update_existing">Update existing books</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-primary-ui">Queue Book Import</button>
                </form>
            </div>

            <div class="admin-panel space-y-5">
                <div>
                    <h3 class="admin-panel-title">User Import</h3>
                    <p class="admin-panel-subtitle">Bulk-create or update institutional and customer accounts with role assignment.</p>
                </div>

                <form method="POST" action="<?php echo e(route('admin.data.imports.users')); ?>" enctype="multipart/form-data" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="form-label">User File</label>
                        <input type="file" name="file" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label">Duplicate Handling</label>
                        <select name="duplicate_strategy" class="form-input">
                            <option value="skip">Skip duplicates</option>
                            <option value="update_existing">Update existing users</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-primary-ui">Queue User Import</button>
                </form>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div class="admin-panel space-y-4">
                <div>
                    <h3 class="admin-panel-title">Book Export</h3>
                    <p class="admin-panel-subtitle">Category, price, stock, and date filtering with custom field selection.</p>
                </div>
                <form method="POST" action="<?php echo e(route('admin.data.exports.books')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="form-label">Format</label>
                        <select name="format" class="form-input">
                            <option value="csv">CSV</option>
                            <option value="xlsx">XLSX</option>
                            <option value="pdf">PDF</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Category</label>
                        <select name="category" class="form-input">
                            <option value="">All categories</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->slug); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="form-label">Min Price</label>
                            <input type="number" step="0.01" name="price_min" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Max Price</label>
                            <input type="number" step="0.01" name="price_max" class="form-input">
                        </div>
                    </div>
                    <div>
                        <label class="form-label">Stock Status</label>
                        <select name="stock_status" class="form-input">
                            <option value="">Any stock state</option>
                            <option value="in_stock">In stock</option>
                            <option value="out_of_stock">Out of stock</option>
                            <option value="low_stock">Low stock</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Columns</label>
                        <div class="grid grid-cols-2 gap-2">
                            <?php $__currentLoopData = $bookColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="admin-checkbox-wrap">
                                    <input type="checkbox" name="columns[]" value="<?php echo e($key); ?>" class="admin-checkbox" checked>
                                    <span><?php echo e($label); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary-ui">Export Books</button>
                </form>
            </div>

            <div class="admin-panel space-y-4">
                <div>
                    <h3 class="admin-panel-title">Order Export</h3>
                    <p class="admin-panel-subtitle">Export admin order reports filtered by status, customer, and date range.</p>
                </div>
                <form method="POST" action="<?php echo e(route('admin.data.exports.orders')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="form-label">Format</label>
                        <select name="format" class="form-input">
                            <option value="csv">CSV</option>
                            <option value="xlsx">XLSX</option>
                            <option value="pdf">PDF</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Status</label>
                        <select name="status" class="form-input">
                            <option value="">All statuses</option>
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Customer</label>
                        <select name="customer_id" class="form-input">
                            <option value="">All customers</option>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Columns</label>
                        <div class="grid grid-cols-1 gap-2">
                            <?php $__currentLoopData = $orderColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="admin-checkbox-wrap">
                                    <input type="checkbox" name="columns[]" value="<?php echo e($key); ?>" class="admin-checkbox" checked>
                                    <span><?php echo e($label); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary-ui">Export Orders</button>
                </form>
            </div>

            <div class="admin-panel space-y-4">
                <div>
                    <h3 class="admin-panel-title">User Export</h3>
                    <p class="admin-panel-subtitle">Redact PII when needed for compliance-oriented datasets.</p>
                </div>
                <form method="POST" action="<?php echo e(route('admin.data.exports.users')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="form-label">Format</label>
                        <select name="format" class="form-input">
                            <option value="csv">CSV</option>
                            <option value="xlsx">XLSX</option>
                            <option value="pdf">PDF</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Role</label>
                        <select name="role" class="form-input">
                            <option value="">All roles</option>
                            <option value="admin">Admin</option>
                            <option value="customer">Customer</option>
                        </select>
                    </div>
                    <label class="admin-checkbox-wrap">
                        <input type="checkbox" name="redact_pii" value="1" class="admin-checkbox">
                        <span>Redact personally identifiable fields</span>
                    </label>
                    <div>
                        <label class="form-label">Columns</label>
                        <div class="grid grid-cols-1 gap-2">
                            <?php $__currentLoopData = $userColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="admin-checkbox-wrap">
                                    <input type="checkbox" name="columns[]" value="<?php echo e($key); ?>" class="admin-checkbox" checked>
                                    <span><?php echo e($label); ?></span>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary-ui">Export Users</button>
                </form>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-6 xl:grid-cols-2">
            <div class="admin-panel">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <h3 class="admin-panel-title">Recent Import Logs</h3>
                        <p class="admin-panel-subtitle">Track queued progress, successes, and failure reports.</p>
                    </div>
                </div>
                <div class="mt-5 ui-table-wrap">
                    <table class="ui-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>File</th>
                                <th>Status</th>
                                <th>Rows</th>
                                <th>Failure Report</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $importLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(ucfirst($log->type)); ?></td>
                                    <td><?php echo e($log->filename); ?></td>
                                    <td><span class="status-pill <?php echo e($log->status === 'completed' ? 'status-pill-completed' : ($log->status === 'failed' ? 'status-pill-pending' : 'status-pill-default')); ?>"><?php echo e(ucfirst($log->status)); ?></span></td>
                                    <td><?php echo e($log->processed_rows); ?>/<?php echo e($log->total_rows); ?></td>
                                    <td>
                                        <?php if($log->failure_report_path): ?>
                                            <a href="<?php echo e(route('admin.data.imports.failures', $log)); ?>" class="nav-action-secondary">Download</a>
                                        <?php else: ?>
                                            <span class="text-ink-400">None</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center text-ink-500">No import logs yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="admin-panel">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <h3 class="admin-panel-title">Recent Export Logs</h3>
                        <p class="admin-panel-subtitle">Queued and completed exports with downloadable output files.</p>
                    </div>
                    <form method="POST" action="<?php echo e(route('admin.data.backups.run')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-action-primary">Run Backup Now</button>
                    </form>
                </div>
                <div class="mt-5 ui-table-wrap">
                    <table class="ui-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Format</th>
                                <th>Status</th>
                                <th>Rows</th>
                                <th>Download</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $exportLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(str_replace('_', ' ', ucfirst($log->type))); ?></td>
                                    <td><?php echo e(strtoupper($log->format)); ?></td>
                                    <td><span class="status-pill <?php echo e($log->status === 'completed' ? 'status-pill-completed' : 'status-pill-default'); ?>"><?php echo e(ucfirst($log->status)); ?></span></td>
                                    <td><?php echo e($log->total_rows); ?></td>
                                    <td>
                                        <?php if($log->status === 'completed'): ?>
                                            <a href="<?php echo e(route('exports.download', $log)); ?>" class="nav-action-secondary">Download</a>
                                        <?php else: ?>
                                            <span class="text-ink-400">Queued</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center text-ink-500">No export logs yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div class="admin-panel">
                <h3 class="admin-panel-title">Backup Monitoring</h3>
                <p class="admin-panel-subtitle">Recent backup, cleanup, and health events.</p>
                <div class="mt-5 space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $backupLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $backup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="rounded-2xl border border-sage-100 bg-sage-50 p-4">
                            <p class="font-semibold text-ink-900"><?php echo e(ucfirst(str_replace('_', ' ', $backup->event))); ?></p>
                            <p class="mt-1 text-sm text-ink-500"><?php echo e(ucfirst($backup->status)); ?> • <?php echo e(optional($backup->happened_at)->format('M d, Y h:i A')); ?></p>
                            <p class="mt-2 text-sm text-ink-600"><?php echo e($backup->message ?: 'No details recorded.'); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-ink-500">No backup events yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="admin-panel">
                <div class="flex items-center justify-between gap-4">
                    <div>
                        <h3 class="admin-panel-title">Audit Overview</h3>
                        <p class="admin-panel-subtitle">Recent auditable events and quick access to the compliance trail.</p>
                    </div>
                    <a href="<?php echo e(route('admin.audits.index')); ?>" class="nav-action-secondary">Open Audit Logs</a>
                </div>
                <div class="mt-5 space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $recentAudits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="rounded-2xl border border-sage-100 bg-white p-4 shadow-soft">
                            <p class="font-semibold text-ink-900"><?php echo e(ucfirst($audit->event)); ?> • <?php echo e(class_basename((string) $audit->auditable_type)); ?></p>
                            <p class="mt-1 text-sm text-ink-500"><?php echo e($audit->user?->name ?: 'System'); ?> • <?php echo e(optional($audit->created_at)->diffForHumans()); ?></p>
                            <p class="mt-2 text-xs text-ink-500"><?php echo e($audit->url ?: 'Console or background task'); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-ink-500">No recent audit entries.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="admin-panel">
                <h3 class="admin-panel-title">API Usage</h3>
                <p class="admin-panel-subtitle">Top endpoints by total requests and throttled hits.</p>
                <div class="mt-5 space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $apiStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="rounded-2xl border border-sage-100 bg-white p-4 shadow-soft">
                            <p class="font-semibold text-ink-900"><?php echo e($stat->endpoint); ?></p>
                            <p class="mt-1 text-sm text-ink-500">Requests: <?php echo e($stat->total_requests); ?></p>
                            <p class="mt-1 text-sm text-ink-500">Throttled: <?php echo e($stat->throttled_requests); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-ink-500">No API traffic recorded yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\admin\data-management\index.blade.php ENDPATH**/ ?>