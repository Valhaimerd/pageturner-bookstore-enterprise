<a <?php echo e($attributes->merge(['class' => 'dropdown-item'])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views/components/dropdown-link.blade.php ENDPATH**/ ?>