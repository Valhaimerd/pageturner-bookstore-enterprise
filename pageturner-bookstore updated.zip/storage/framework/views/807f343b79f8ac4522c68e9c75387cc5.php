<?php echo e($slot); ?>

<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>