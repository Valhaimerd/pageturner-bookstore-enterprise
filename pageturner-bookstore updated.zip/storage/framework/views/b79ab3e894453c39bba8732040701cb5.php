<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                Order Placed
            </h2>
            <p class="mt-1 text-sm text-ink-500">
                Your order was submitted successfully.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <section class="success-hero">
            <div class="flex flex-col gap-5 sm:flex-row sm:items-start">
                <div class="success-icon">
                    <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m5 13 4 4L19 7" />
                    </svg>
                </div>

                <div class="flex-1">
                    <h1 class="success-title">Your order was placed successfully</h1>
                    <p class="success-text">
                        Keep your order and receipt numbers for reference. You can also view this order later from your dashboard or orders page.
                    </p>

                    <div class="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
                        <div class="order-info-card">
                            <p class="order-info-label">Order Number</p>
                            <p class="order-info-value"><?php echo e($order->order_number); ?></p>
                        </div>

                        <div class="order-info-card">
                            <p class="order-info-label">Receipt Number</p>
                            <p class="order-info-value"><?php echo e($order->receipt_number); ?></p>
                        </div>

                        <div class="order-info-card">
                            <p class="order-info-label">Status</p>
                            <p class="order-info-value"><?php echo e(ucfirst($order->status)); ?></p>
                        </div>

                        <div class="order-info-card">
                            <p class="order-info-label">Total</p>
                            <p class="order-info-value">₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="content-card">
            <h3 class="content-card-title">Items</h3>
            <p class="content-card-subtitle">
                Books included in this completed checkout.
            </p>

            <div class="mt-5 space-y-4">
                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-2xl border border-sage-100 bg-sage-50 p-4">
                        <p class="font-semibold text-ink-900"><?php echo e($item->book_title); ?></p>
                        <p class="mt-1 text-sm text-ink-500">Author: <?php echo e($item->book_author); ?></p>
                        <p class="mt-1 text-sm text-ink-500">Quantity: <?php echo e($item->quantity); ?></p>
                        <p class="mt-1 text-sm text-ink-500">Unit Price: ₱<?php echo e(number_format((float) $item->unit_price, 2)); ?></p>
                        <p class="mt-2 text-sm font-semibold text-ink-800">
                            Line Total: ₱<?php echo e(number_format((float) $item->line_total, 2)); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-6 flex flex-wrap gap-3">
                <a href="<?php echo e(route('books.index')); ?>" class="nav-action-primary">
                    Continue Shopping
                </a>

                <a href="<?php echo e(route('customer.dashboard')); ?>" class="nav-action-secondary">
                    Go to Dashboard
                </a>

                <a href="<?php echo e(route('orders.receipt', $order)); ?>" class="nav-action-secondary">
                    View Receipt
                </a>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\orders\success.blade.php ENDPATH**/ ?>