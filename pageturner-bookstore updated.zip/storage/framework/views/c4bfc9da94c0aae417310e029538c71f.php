<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                Admin Dashboard
            </h2>
            <p class="mt-1 text-sm text-ink-500">
                Monitor users, catalog, orders, revenue, and recent activity.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <section class="admin-hero">
            <span class="dashboard-chip">Management Overview</span>
            <h1 class="admin-title mt-4">Store control center</h1>
            <p class="admin-subtitle">
                Manage categories, books, customer orders, and recent review activity from one place.
            </p>

            <div class="mt-6 admin-action-grid">
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="admin-action-card">
                    <h3 class="admin-action-title">Manage Categories</h3>
                    <p class="admin-action-text">Create, update, and organize book categories.</p>
                </a>

                <a href="<?php echo e(route('admin.books.index')); ?>" class="admin-action-card">
                    <h3 class="admin-action-title">Manage Books</h3>
                    <p class="admin-action-text">Maintain the catalog, stock, pricing, and featured books.</p>
                </a>

                <a href="<?php echo e(route('admin.orders.index')); ?>" class="admin-action-card">
                    <h3 class="admin-action-title">Manage Orders</h3>
                    <p class="admin-action-text">Review orders, payment status, and customer information.</p>
                </a>

                <a href="<?php echo e(route('admin.data.index')); ?>" class="admin-action-card">
                    <h3 class="admin-action-title">Data Management</h3>
                    <p class="admin-action-text">Run imports, exports, backups, and operational reports.</p>
                </a>

                <a href="<?php echo e(route('admin.audits.index')); ?>" class="admin-action-card">
                    <h3 class="admin-action-title">Audit Logs</h3>
                    <p class="admin-action-text">Inspect sensitive changes and security-relevant activity.</p>
                </a>
            </div>
        </section>

        <section class="admin-stat-grid">
            <div class="metric-card">
                <p class="metric-label">Total Users</p>
                <p class="metric-value"><?php echo e($totalUsers); ?></p>
                <p class="metric-note">All registered accounts</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Customers</p>
                <p class="metric-value"><?php echo e($totalCustomers); ?></p>
                <p class="metric-note">Customer accounts only</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Books</p>
                <p class="metric-value"><?php echo e($totalBooks); ?></p>
                <p class="metric-note">Catalog entries</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Categories</p>
                <p class="metric-value"><?php echo e($totalCategories); ?></p>
                <p class="metric-note">Available groups</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Orders</p>
                <p class="metric-value"><?php echo e($totalOrders); ?></p>
                <p class="metric-note">Customer purchases</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Revenue</p>
                <p class="metric-value">₱<?php echo e(number_format((float) $totalRevenue, 2)); ?></p>
                <p class="metric-note">Recorded total revenue</p>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-5 lg:grid-cols-4">
            <div class="metric-card">
                <p class="metric-label">Pending</p>
                <p class="metric-value"><?php echo e($statusCounts['pending'] ?? 0); ?></p>
                <p class="metric-note">Awaiting action</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Processing</p>
                <p class="metric-value"><?php echo e($statusCounts['processing'] ?? 0); ?></p>
                <p class="metric-note">Currently handled</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Completed</p>
                <p class="metric-value"><?php echo e($statusCounts['completed'] ?? 0); ?></p>
                <p class="metric-note">Finished orders</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Cancelled</p>
                <p class="metric-value"><?php echo e($statusCounts['cancelled'] ?? 0); ?></p>
                <p class="metric-note">Stopped orders</p>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
            <div class="metric-card">
                <p class="metric-label">Imports Today</p>
                <p class="metric-value"><?php echo e($recentImportCount); ?></p>
                <p class="metric-note">Queued or completed transfer jobs</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Exports Today</p>
                <p class="metric-value"><?php echo e($recentExportCount); ?></p>
                <p class="metric-note">Generated data portability files</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">Latest Backup</p>
                <p class="metric-value"><?php echo e(ucfirst($latestBackupStatus)); ?></p>
                <p class="metric-note">Most recent backup monitor result</p>
            </div>

            <div class="metric-card">
                <p class="metric-label">API Throttle Hits</p>
                <p class="metric-value"><?php echo e($apiThrottleHits); ?></p>
                <p class="metric-note">429 responses in the last 24 hours</p>
            </div>
        </section>

        <section class="grid grid-cols-1 gap-6 xl:grid-cols-2">
            <div class="admin-panel">
                <h3 class="admin-panel-title">Latest Orders</h3>
                <p class="admin-panel-subtitle">Most recent customer transactions.</p>

                <div class="mt-5">
                    <?php if($latestOrders->count()): ?>
                        <div class="ui-table-wrap">
                            <table class="ui-table">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Customer</th>
                                        <th>Status</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $latestOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $status = strtolower($order->status);
                                            $statusClass = match($status) {
                                                'pending' => 'status-pill status-pill-pending',
                                                'completed' => 'status-pill status-pill-completed',
                                                default => 'status-pill status-pill-default',
                                            };
                                        ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="font-semibold text-brand-700 hover:underline">
                                                    <?php echo e($order->order_number); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($order->user?->email); ?></td>
                                            <td><span class="<?php echo e($statusClass); ?>"><?php echo e(ucfirst($order->status)); ?></span></td>
                                            <td>₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="mt-5 text-sm text-ink-500">No orders yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="admin-panel">
                <h3 class="admin-panel-title">Latest Reviews</h3>
                <p class="admin-panel-subtitle">Recent customer feedback on books.</p>

                <div class="mt-5">
                    <?php if($latestReviews->count()): ?>
                        <div class="space-y-4">
                            <?php $__currentLoopData = $latestReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-2xl border border-sage-100 bg-sage-50 p-4">
                                    <p class="font-semibold text-ink-900"><?php echo e($review->book?->title); ?></p>
                                    <p class="mt-1 text-sm text-ink-500"><?php echo e($review->user?->name); ?> • <?php echo e($review->rating); ?>/5</p>
                                    <p class="mt-2 text-sm leading-6 text-ink-600"><?php echo e($review->comment ?: 'No comment.'); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <p class="mt-5 text-sm text-ink-500">No reviews yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>