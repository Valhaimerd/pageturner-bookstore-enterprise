<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    Book Details
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    View book information, availability, and reader reviews.
                </p>
            </div>

            <a href="<?php echo e(route('books.index')); ?>" class="nav-action-secondary">
                Back to Catalog
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(session('success')): ?>
            <div class="soft-alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="soft-alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <section class="book-detail-layout">
            <div class="book-detail-cover-card">
                <?php if($book->cover_image): ?>
                    <img
                        src="<?php echo e(asset('storage/' . $book->cover_image)); ?>"
                        alt="<?php echo e($book->title); ?>"
                        class="book-detail-cover"
                    >
                <?php else: ?>
                    <div class="book-detail-placeholder">
                        No Image
                    </div>
                <?php endif; ?>
            </div>

            <div class="book-detail-info-card">
                <?php if($book->category?->name): ?>
                    <span class="book-category-pill">
                        <?php echo e($book->category->name); ?>

                    </span>
                <?php endif; ?>

                <h1 class="mt-4 text-3xl font-bold tracking-tight text-ink-900">
                    <?php echo e($book->title); ?>

                </h1>

                <p class="mt-2 text-lg text-ink-600">
                    by <?php echo e($book->author); ?>

                </p>

                <p class="mt-4 text-3xl font-bold text-brand-700">
                    ₱<?php echo e(number_format((float) $book->price, 2)); ?>

                </p>

                <div class="detail-stat-grid">
                    <div class="detail-stat-box">
                        <p class="detail-stat-label">Stock</p>
                        <p class="detail-stat-value">
                            <?php if($book->stock > 0): ?>
                                <span class="stock-good"><?php echo e($book->stock); ?> available</span>
                            <?php else: ?>
                                <span class="stock-bad">Out of stock</span>
                            <?php endif; ?>
                        </p>
                    </div>

                    <div class="detail-stat-box">
                        <p class="detail-stat-label">Average Rating</p>
                        <p class="detail-stat-value">
                            <?php echo e($reviewCount ? $averageRating : 'No ratings yet'); ?>

                        </p>
                    </div>

                    <div class="detail-stat-box">
                        <p class="detail-stat-label">Total Reviews</p>
                        <p class="detail-stat-value"><?php echo e($reviewCount); ?></p>
                    </div>

                    <?php if($book->isbn): ?>
                        <div class="detail-stat-box">
                            <p class="detail-stat-label">ISBN</p>
                            <p class="detail-stat-value"><?php echo e($book->isbn); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if($book->published_at): ?>
                        <div class="detail-stat-box">
                            <p class="detail-stat-label">Published</p>
                            <p class="detail-stat-value"><?php echo e($book->published_at->format('F d, Y')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mt-6">
                    <h3 class="text-lg font-semibold text-ink-900">Description</h3>
                    <p class="mt-3 whitespace-pre-line text-sm leading-7 text-ink-600">
                        <?php echo e($book->description ?: 'No description available.'); ?>

                    </p>
                </div>

                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->isCustomer()): ?>
                        <div class="buy-panel">
                            <?php if($book->stock > 0): ?>
                                <div class="space-y-4">
                                    <form method="POST" action="<?php echo e(route('cart.store', $book->slug)); ?>" class="space-y-3">
                                        <?php echo csrf_field(); ?>

                                        <div class="max-w-xs">
                                            <label for="cart_quantity" class="form-label">
                                                Quantity
                                            </label>
                                            <input
                                                id="cart_quantity"
                                                name="quantity"
                                                type="number"
                                                min="1"
                                                max="<?php echo e($book->stock); ?>"
                                                value="1"
                                                class="form-input"
                                            >
                                        </div>

                                        <div class="flex flex-wrap gap-3">
                                            <button type="submit" class="nav-action-primary">
                                                Add to Cart
                                            </button>
                                        </div>
                                    </form>

                                    <form method="POST" action="<?php echo e(route('cart.buy_now', $book->slug)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="quantity" value="1">

                                        <button type="submit" class="nav-action-secondary">
                                            Buy Now
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <p class="stock-bad">Out of stock</p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="mt-6">
                        <a href="<?php echo e(route('login')); ?>" class="nav-action-primary">
                            Login to Buy
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="content-card">
            <h3 class="content-card-title">Reviews</h3>
            <p class="content-card-subtitle">
                Ratings and comments from readers.
            </p>

            <div class="mt-5 space-y-5">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->isCustomer()): ?>
                        <?php if(!$purchased): ?>
                            <div class="soft-alert-warning">
                                You can only review this book after purchasing it.
                            </div>
                        <?php elseif($canReview): ?>
                            <div class="review-form-card">
                                <p class="text-base font-semibold text-ink-900 mb-4">
                                    <?php echo e($userReview ? 'Edit Your Review' : 'Write a Review'); ?>

                                </p>

                                <form
                                    method="POST"
                                    action="<?php echo e($userReview ? route('reviews.update', $userReview) : route('reviews.store', $book->slug)); ?>"
                                    class="space-y-4"
                                >
                                    <?php echo csrf_field(); ?>
                                    <?php if($userReview): ?>
                                        <?php echo method_field('PUT'); ?>
                                    <?php endif; ?>

                                    <div class="max-w-xs">
                                        <label class="form-label">Rating (1-5)</label>
                                        <input
                                            type="number"
                                            name="rating"
                                            min="1"
                                            max="5"
                                            value="<?php echo e(old('rating', $userReview?->rating ?? 5)); ?>"
                                            class="form-input"
                                            required
                                        >
                                        <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div>
                                        <label class="form-label">Comment</label>
                                        <textarea
                                            name="comment"
                                            rows="4"
                                            class="form-input"
                                        ><?php echo e(old('comment', $userReview?->comment)); ?></textarea>
                                        <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="flex flex-wrap gap-3">
                                        <button type="submit" class="btn-primary-ui">
                                            <?php echo e($userReview ? 'Update Review' : 'Submit Review'); ?>

                                        </button>
                                    </div>
                                </form>

                                <?php if($userReview): ?>
                                    <form method="POST" action="<?php echo e(route('reviews.destroy', $userReview)); ?>" class="mt-3">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button
                                            type="submit"
                                            onclick="return confirm('Delete your review?')"
                                            class="btn-danger-ui"
                                        >
                                            Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>

                <?php $__empty_1 = true; $__currentLoopData = $book->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="review-card">
                        <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                            <p class="font-semibold text-ink-900"><?php echo e($review->user?->name); ?></p>
                            <p class="text-sm text-ink-500"><?php echo e($review->created_at->format('M d, Y')); ?></p>
                        </div>

                        <p class="mt-2 text-sm font-semibold text-brand-700">
                            Rating: <?php echo e($review->rating); ?>/5
                        </p>

                        <p class="mt-3 text-sm leading-6 text-ink-600">
                            <?php echo e($review->comment ?: 'No comment.'); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-ink-500">No reviews yet.</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\catalog\show.blade.php ENDPATH**/ ?>