<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    Checkout
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    Complete your shipping and payment details before placing the order.
                </p>
            </div>

            <a href="<?php echo e(route('cart.index')); ?>" class="nav-action-secondary">
                Back to Cart
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="checkout-layout">
        <section class="checkout-form-card">
            <?php if($errors->has('checkout')): ?>
                <div class="soft-alert-danger mb-6">
                    <?php echo e($errors->first('checkout')); ?>

                </div>
            <?php endif; ?>

            <div>
                <h3 class="checkout-section-title">Shipping and Buyer Information</h3>
                <p class="checkout-section-text">
                    Review your details carefully before placing the order.
                </p>
            </div>

            <form method="POST" action="<?php echo e(route('checkout.store')); ?>" class="checkout-group">
                <?php echo csrf_field(); ?>

                <?php if($selectedItemId): ?>
                    <input type="hidden" name="item_id" value="<?php echo e($selectedItemId); ?>">
                <?php endif; ?>

                <div class="checkout-grid-2">
                    <div>
                        <label for="buyer_name" class="form-label">Buyer Name</label>
                        <input
                            id="buyer_name"
                            name="buyer_name"
                            type="text"
                            value="<?php echo e(old('buyer_name', $user->name)); ?>"
                            class="form-input"
                            required
                        >
                        <?php $__errorArgs = ['buyer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="buyer_email" class="form-label">Buyer Email</label>
                        <input
                            id="buyer_email"
                            name="buyer_email"
                            type="email"
                            value="<?php echo e(old('buyer_email', $user->email)); ?>"
                            class="form-input"
                            required
                        >
                        <?php $__errorArgs = ['buyer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div>
                    <label for="buyer_phone" class="form-label">Phone</label>
                    <input
                        id="buyer_phone"
                        name="buyer_phone"
                        type="text"
                        value="<?php echo e(old('buyer_phone', $user->phone)); ?>"
                        class="form-input"
                    >
                    <?php $__errorArgs = ['buyer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="address_line_1" class="form-label">Address Line 1</label>
                    <input
                        id="address_line_1"
                        name="address_line_1"
                        type="text"
                        value="<?php echo e(old('address_line_1', $user->default_address_line_1)); ?>"
                        class="form-input"
                        required
                    >
                    <?php $__errorArgs = ['address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="address_line_2" class="form-label">Address Line 2</label>
                    <input
                        id="address_line_2"
                        name="address_line_2"
                        type="text"
                        value="<?php echo e(old('address_line_2', $user->default_address_line_2)); ?>"
                        class="form-input"
                    >
                    <?php $__errorArgs = ['address_line_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="checkout-grid-3">
                    <div>
                        <label for="city" class="form-label">City</label>
                        <input
                            id="city"
                            name="city"
                            type="text"
                            value="<?php echo e(old('city', $user->default_city)); ?>"
                            class="form-input"
                            required
                        >
                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="province" class="form-label">Province</label>
                        <input
                            id="province"
                            name="province"
                            type="text"
                            value="<?php echo e(old('province', $user->default_province)); ?>"
                            class="form-input"
                            required
                        >
                        <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label for="postal_code" class="form-label">Postal Code</label>
                        <input
                            id="postal_code"
                            name="postal_code"
                            type="text"
                            value="<?php echo e(old('postal_code', $user->default_postal_code)); ?>"
                            class="form-input"
                            required
                        >
                        <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div>
                    <label for="country" class="form-label">Country</label>
                    <input
                        id="country"
                        name="country"
                        type="text"
                        value="<?php echo e(old('country', $user->default_country ?: 'Philippines')); ?>"
                        class="form-input"
                        required
                    >
                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="payment_method" class="form-label">Payment Method</label>
                    <select
                        id="payment_method"
                        name="payment_method"
                        class="form-input"
                        required
                    >
                        <option value="cash_on_delivery" <?php echo e(old('payment_method') === 'cash_on_delivery' ? 'selected' : ''); ?>>
                            Cash on Delivery
                        </option>
                        <option value="manual" <?php echo e(old('payment_method') === 'manual' ? 'selected' : ''); ?>>
                            Manual Payment
                        </option>
                    </select>
                    <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="notes" class="form-label">Notes</label>
                    <textarea
                        id="notes"
                        name="notes"
                        rows="4"
                        class="form-input"
                    ><?php echo e(old('notes')); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="pt-2">
                    <button type="submit" class="nav-action-primary">
                        Place Order
                    </button>
                </div>
            </form>
        </section>

        <aside class="checkout-summary-card">
            <h3 class="checkout-section-title">Order Summary</h3>
            <p class="checkout-section-text">
                Review the items included in this order.
            </p>

            <div class="mt-6 space-y-4">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="order-line">
                        <p class="font-semibold text-ink-900"><?php echo e($item->book?->title); ?></p>
                        <p class="mt-1 text-sm text-ink-500">Author: <?php echo e($item->book?->author); ?></p>
                        <p class="mt-1 text-sm text-ink-500">Price: ₱<?php echo e(number_format((float) $item->unit_price, 2)); ?></p>
                        <p class="mt-1 text-sm text-ink-500">Quantity: <?php echo e($item->quantity); ?></p>
                        <p class="mt-2 text-sm font-semibold text-ink-800">
                            Line Total: ₱<?php echo e(number_format((float) $item->unit_price * (int) $item->quantity, 2)); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-6 space-y-3">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>₱<?php echo e(number_format((float) $subtotal, 2)); ?></span>
                </div>

                <div class="summary-row">
                    <span>Shipping</span>
                    <span>₱0.00</span>
                </div>

                <div class="summary-row">
                    <span>Tax</span>
                    <span>₱0.00</span>
                </div>

                <div class="summary-total-row">
                    <span>Total</span>
                    <span>₱<?php echo e(number_format((float) $subtotal, 2)); ?></span>
                </div>
            </div>
        </aside>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\checkout\index.blade.php ENDPATH**/ ?>