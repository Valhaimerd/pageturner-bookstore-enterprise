<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                Dashboard
            </h2>
            <p class="mt-1 text-sm text-ink-500">
                Overview of your bookstore account.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(auth()->user() && !auth()->user()->hasVerifiedEmail()): ?>
            <div class="soft-alert-warning">
                Your email is not verified yet. You need verification before checkout and reviews.
                <a class="ml-1 font-semibold underline" href="<?php echo e(route('verification.notice')); ?>">Verify now</a>
            </div>
        <?php endif; ?>

        <section class="dashboard-hero">
            <span class="dashboard-chip">Account Overview</span>
            <h1 class="dashboard-title mt-4">
                Welcome back, <?php echo e(auth()->user()->name); ?>.
            </h1>
            <p class="dashboard-subtitle">
                Use this space to browse books, manage your cart, review your orders, and update your profile details.
            </p>

            <div class="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <a href="<?php echo e(route('books.index')); ?>" class="nav-action-primary">
                    Browse Books
                </a>

                <a href="<?php echo e(route('cart.index')); ?>" class="nav-action-secondary">
                    View Cart
                </a>

                <a href="<?php echo e(route('orders.index')); ?>" class="nav-action-secondary">
                    My Orders
                </a>

                <a href="<?php echo e(route('profile.edit')); ?>" class="nav-action-secondary">
                    Edit Profile
                </a>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\dashboard.blade.php ENDPATH**/ ?>