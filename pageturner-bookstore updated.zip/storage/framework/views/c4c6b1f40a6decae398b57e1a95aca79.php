<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #1f2937; }
        h1 { font-size: 18px; margin-bottom: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #d1d5db; padding: 8px; text-align: left; }
        th { background: #f3f4f6; }
    </style>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <table>
        <thead>
            <tr>
                <th>Order #</th>
                <th>Receipt #</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Total</th>
                <th>Placed</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->order_number); ?></td>
                    <td><?php echo e($order->receipt_number); ?></td>
                    <td><?php echo e($order->buyer_name); ?><br><?php echo e($order->buyer_email); ?></td>
                    <td><?php echo e(ucfirst($order->status)); ?></td>
                    <td><?php echo e(ucfirst($order->payment_status)); ?></td>
                    <td><?php echo e(number_format((float) $order->total_amount, 2)); ?></td>
                    <td><?php echo e(optional($order->placed_at ?? $order->created_at)->format('Y-m-d H:i')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\exports\orders-pdf.blade.php ENDPATH**/ ?>