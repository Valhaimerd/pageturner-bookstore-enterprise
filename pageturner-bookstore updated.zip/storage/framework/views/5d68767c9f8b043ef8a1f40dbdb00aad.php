<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    My Cart
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    Review items, update quantities, and continue to checkout.
                </p>
            </div>

            <a href="<?php echo e(route('books.index')); ?>" class="nav-action-secondary">
                Continue Shopping
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(session('success')): ?>
            <div class="soft-alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="soft-alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php if($cart->items->count()): ?>
            <div class="cart-layout">
                <div class="cart-main space-y-5">
                    <?php $__currentLoopData = $cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="cart-item-card">
                            <div class="cart-item-layout">
                                <div class="cart-item-book">
                                    <div class="flex items-start gap-4">
                                        <?php if($item->book?->cover_image): ?>
                                            <img
                                                src="<?php echo e(asset('storage/' . $item->book->cover_image)); ?>"
                                                alt="<?php echo e($item->book->title); ?>"
                                                class="cart-thumb"
                                            >
                                        <?php else: ?>
                                            <div class="cart-thumb-placeholder">
                                                No Image
                                            </div>
                                        <?php endif; ?>

                                        <div>
                                            <h3 class="text-lg font-semibold text-ink-900">
                                                <?php echo e($item->book?->title); ?>

                                            </h3>
                                            <p class="mt-1 text-sm text-ink-500">
                                                <?php echo e($item->book?->author); ?>

                                            </p>
                                            <p class="mt-2 text-sm text-ink-500">
                                                Stock: <?php echo e($item->book?->stock); ?>

                                            </p>
                                            <p class="mt-3 text-lg font-bold text-brand-700">
                                                ₱<?php echo e(number_format((float) $item->unit_price, 2)); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <div class="cart-item-qty">
                                    <p class="text-sm font-semibold text-ink-800 mb-3">Quantity</p>

                                    <form
                                        method="POST"
                                        action="<?php echo e(route('cart-items.update', $item)); ?>"
                                        class="space-y-3"
                                    >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>

                                        <input
                                            type="number"
                                            name="quantity"
                                            min="1"
                                            max="<?php echo e($item->book?->stock ?? 1); ?>"
                                            value="<?php echo e($item->quantity); ?>"
                                            class="form-input"
                                        >

                                        <button type="submit" class="btn-secondary-ui w-full sm:w-auto">
                                            Update
                                        </button>
                                    </form>
                                </div>

                                <div class="cart-item-total">
                                    <p class="text-sm font-semibold text-ink-800 mb-3">Total</p>
                                    <p class="text-xl font-bold text-ink-900">
                                        ₱<?php echo e(number_format((float) $item->unit_price * (int) $item->quantity, 2)); ?>

                                    </p>
                                </div>

                                <div class="cart-item-actions">
                                    <p class="text-sm font-semibold text-ink-800 mb-3">Actions</p>

                                    <div class="flex flex-col gap-3">
                                        <a
                                            href="<?php echo e(route('checkout.index', ['item' => $item->id])); ?>"
                                            class="nav-action-primary text-center"
                                        >
                                            Checkout This
                                        </a>

                                        <form method="POST" action="<?php echo e(route('cart-items.destroy', $item)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button
                                                type="submit"
                                                onclick="return confirm('Remove this item?')"
                                                class="btn-danger-ui w-full"
                                            >
                                                Remove
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <aside class="cart-summary-card">
                    <h3 class="checkout-section-title">Cart Summary</h3>
                    <p class="checkout-section-text">
                        Review your subtotal and continue to full checkout.
                    </p>

                    <div class="mt-6 space-y-4">
                        <div class="summary-row">
                            <span>Items</span>
                            <span><?php echo e($cart->items->count()); ?></span>
                        </div>

                        <div class="summary-total-row">
                            <span>Subtotal</span>
                            <span>₱<?php echo e(number_format((float) $subtotal, 2)); ?></span>
                        </div>
                    </div>

                    <div class="mt-6 space-y-3">
                        <a href="<?php echo e(route('checkout.index')); ?>" class="nav-action-primary w-full text-center">
                            Checkout All
                        </a>

                        <form method="POST" action="<?php echo e(route('cart.clear')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button
                                type="submit"
                                onclick="return confirm('Clear the entire cart?')"
                                class="btn-danger-ui w-full"
                            >
                                Clear Cart
                            </button>
                        </form>
                    </div>
                </aside>
            </div>
        <?php else: ?>
            <div class="empty-state-card">
                <h3 class="empty-state-title">Your cart is empty</h3>
                <p class="empty-state-text">
                    Add some books to your cart before checking out.
                </p>

                <div class="mt-5">
                    <a href="<?php echo e(route('books.index')); ?>" class="nav-action-primary">
                        Browse Books
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\cart\index.blade.php ENDPATH**/ ?>