<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    Audit Logs
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    Review sensitive activity, compare changes, and export compliance trails.
                </p>
            </div>

            <form method="POST" action="<?php echo e(route('admin.audits.export')); ?>" class="flex gap-2">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($value): ?>
                        <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit" name="format" value="csv" class="nav-action-secondary">Export CSV</button>
                <button type="submit" name="format" value="pdf" class="nav-action-primary">Export PDF</button>
            </form>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <section class="admin-panel">
            <form method="GET" action="<?php echo e(route('admin.audits.index')); ?>" class="grid grid-cols-1 gap-4 md:grid-cols-5">
                <div>
                    <label class="form-label">User</label>
                    <select name="user_id" class="form-input">
                        <option value="">All users</option>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php if(($filters['user_id'] ?? '') == $user->id): echo 'selected'; endif; ?>><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="form-label">Event</label>
                    <input type="text" name="event" value="<?php echo e($filters['event'] ?? ''); ?>" class="form-input" placeholder="updated">
                </div>
                <div>
                    <label class="form-label">Model</label>
                    <input type="text" name="model" value="<?php echo e($filters['model'] ?? ''); ?>" class="form-input" placeholder="Book">
                </div>
                <div>
                    <label class="form-label">From</label>
                    <input type="date" name="from" value="<?php echo e($filters['from'] ?? ''); ?>" class="form-input">
                </div>
                <div>
                    <label class="form-label">To</label>
                    <input type="date" name="to" value="<?php echo e($filters['to'] ?? ''); ?>" class="form-input">
                </div>
                <div class="md:col-span-5 flex gap-3">
                    <button type="submit" class="btn-primary-ui">Apply Filters</button>
                    <a href="<?php echo e(route('admin.audits.index')); ?>" class="btn-secondary-ui">Reset</a>
                </div>
            </form>
        </section>

        <section class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="admin-panel">
                    <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                            <h3 class="admin-panel-title"><?php echo e(ucfirst($audit->event)); ?> • <?php echo e(class_basename((string) $audit->auditable_type)); ?> #<?php echo e($audit->auditable_id); ?></h3>
                            <p class="admin-panel-subtitle"><?php echo e($audit->user?->name ?: 'System'); ?> • <?php echo e(optional($audit->created_at)->format('M d, Y h:i A')); ?></p>
                        </div>
                        <div class="text-right text-xs text-ink-500">
                            <p><?php echo e($audit->method ?: 'CLI'); ?> <?php echo e($audit->url ?: 'background task'); ?></p>
                            <p>Checksum: <?php echo e($audit->checksum ?: 'n/a'); ?></p>
                        </div>
                    </div>

                    <div class="mt-5 grid grid-cols-1 gap-4 lg:grid-cols-2">
                        <div class="rounded-2xl border border-sage-100 bg-sage-50 p-4">
                            <p class="text-sm font-semibold text-ink-900">Old Values</p>
                            <div class="mt-3 space-y-2 text-sm text-ink-600">
                                <?php $__empty_2 = true; $__currentLoopData = $audit->old_values ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <div><strong><?php echo e($key); ?>:</strong> <?php echo e(is_array($value) ? json_encode($value) : $value); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <p>No previous values.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="rounded-2xl border border-brand-100 bg-brand-50/40 p-4">
                            <p class="text-sm font-semibold text-ink-900">New Values</p>
                            <div class="mt-3 space-y-2 text-sm text-ink-600">
                                <?php $__empty_2 = true; $__currentLoopData = $audit->new_values ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <div><strong><?php echo e($key); ?>:</strong> <?php echo e(is_array($value) ? json_encode($value) : $value); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <p>No new values.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state-card">
                    <h3 class="empty-state-title">No audit logs found</h3>
                    <p class="empty-state-text">Try broadening the filters or perform auditable actions in the system.</p>
                </div>
            <?php endif; ?>
        </section>

        <div><?php echo e($audits->links()); ?></div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\admin\audits\index.blade.php ENDPATH**/ ?>