<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    Order Details
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    View full order information, buyer details, and purchased items.
                </p>
            </div>

            <a href="<?php echo e(route('orders.index')); ?>" class="nav-action-secondary">
                Back to Orders
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php
            $status = strtolower($order->status);
            $statusClass = match($status) {
                'pending' => 'status-pill status-pill-pending',
                'completed' => 'status-pill status-pill-completed',
                default => 'status-pill status-pill-default',
            };

            $paymentStatus = strtolower($order->payment_status);
            $paymentClass = match($paymentStatus) {
                'pending' => 'status-pill status-pill-pending',
                'paid', 'completed' => 'status-pill status-pill-completed',
                default => 'status-pill status-pill-default',
            };
        ?>

        <section class="order-summary-grid">
            <div class="order-info-card">
                <p class="order-info-label">Order Number</p>
                <p class="order-info-value"><?php echo e($order->order_number); ?></p>
            </div>

            <div class="order-info-card">
                <p class="order-info-label">Receipt Number</p>
                <p class="order-info-value"><?php echo e($order->receipt_number ?: '—'); ?></p>
            </div>

            <div class="order-info-card">
                <p class="order-info-label">Order Status</p>
                <div class="mt-2">
                    <span class="<?php echo e($statusClass); ?>"><?php echo e(ucfirst($order->status)); ?></span>
                </div>
            </div>

            <div class="order-info-card">
                <p class="order-info-label">Total Amount</p>
                <p class="order-info-value">₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></p>
            </div>
        </section>

        <div class="order-layout">
            <section class="order-main-card">
                <h3 class="content-card-title">Purchased Items</h3>
                <p class="content-card-subtitle">
                    Breakdown of all books included in this order.
                </p>

                <div class="mt-5 ui-table-wrap">
                    <table class="ui-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Unit</th>
                                <th>Qty</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="font-semibold text-ink-900"><?php echo e($item->book_title); ?></td>
                                    <td><?php echo e($item->book_author); ?></td>
                                    <td>₱<?php echo e(number_format((float) $item->unit_price, 2)); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td>₱<?php echo e(number_format((float) $item->line_total, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <aside class="space-y-6">
                <section class="order-side-card">
                    <h3 class="content-card-title">Order Information</h3>
                    <div class="mt-4 detail-list">
                        <p><strong>Status:</strong> <span class="<?php echo e($statusClass); ?>"><?php echo e(ucfirst($order->status)); ?></span></p>
                        <p><strong>Payment Status:</strong> <span class="<?php echo e($paymentClass); ?>"><?php echo e(ucfirst($order->payment_status)); ?></span></p>
                        <p><strong>Total:</strong> ₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></p>
                        <p><strong>Date:</strong> <?php echo e($order->created_at->format('M d, Y h:i A')); ?></p>
                    </div>

                    <div class="mt-5">
                        <a href="<?php echo e(route('orders.receipt', $order)); ?>" class="nav-action-primary">
                            View Receipt
                        </a>
                    </div>
                </section>

                <section class="order-side-card">
                    <h3 class="content-card-title">Buyer</h3>
                    <div class="mt-4 detail-list">
                        <p><strong>Name:</strong> <?php echo e($order->buyer_name); ?></p>
                        <p><strong>Email:</strong> <?php echo e($order->buyer_email); ?></p>
                        <p><strong>Phone:</strong> <?php echo e($order->buyer_phone ?: '—'); ?></p>
                    </div>
                </section>

                <section class="order-side-card">
                    <h3 class="content-card-title">Delivery Address</h3>
                    <div class="mt-4 detail-list">
                        <p><?php echo e($order->address_line_1); ?></p>
                        <?php if($order->address_line_2): ?>
                            <p><?php echo e($order->address_line_2); ?></p>
                        <?php endif; ?>
                        <p><?php echo e($order->city); ?>, <?php echo e($order->province); ?> <?php echo e($order->postal_code); ?></p>
                        <p><?php echo e($order->country); ?></p>
                    </div>
                </section>
            </aside>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\orders\show.blade.php ENDPATH**/ ?>