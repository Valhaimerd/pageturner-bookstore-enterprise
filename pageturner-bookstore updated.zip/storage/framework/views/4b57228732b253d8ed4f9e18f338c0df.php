<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="catalog-header-card">
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight text-center">
                Book Catalog
            </h2>
            <p class="mt-1 text-sm text-ink-500 text-center">
                Browse available books by category and view their details.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="catalog-page-wrap space-y-6">
        <section class="store-toolbar catalog-toolbar-wrap">
            <div>
                <h3 class="store-toolbar-title">Find your next read</h3>
                <p class="store-toolbar-text">
                    Explore the collection and filter by category.
                </p>
            </div>

            <form method="GET" action="<?php echo e(route('books.index')); ?>" class="filter-form">
                <select name="category" class="filter-select">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->slug); ?>" <?php echo e($selectedCategory === $category->slug ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button type="submit" class="nav-action-primary">
                    Filter
                </button>

                <a href="<?php echo e(route('books.index')); ?>" class="nav-action-secondary">
                    Reset
                </a>
            </form>
        </section>

        <?php if($books->count()): ?>
            <section class="catalog-grid">
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="book-card">
                        <?php if($book->cover_image): ?>
                            <img
                                src="<?php echo e(asset('storage/' . $book->cover_image)); ?>"
                                alt="<?php echo e($book->title); ?>"
                                class="book-card-media"
                            >
                        <?php else: ?>
                            <div class="book-card-placeholder">
                                No Image
                            </div>
                        <?php endif; ?>

                        <div class="book-card-body">
                            <?php if($book->category?->name): ?>
                                <span class="book-category-pill">
                                    <?php echo e($book->category->name); ?>

                                </span>
                            <?php endif; ?>

                            <h3 class="book-title"><?php echo e($book->title); ?></h3>
                            <p class="book-author">by <?php echo e($book->author); ?></p>

                            <p class="book-price">
                                ₱<?php echo e(number_format((float) $book->price, 2)); ?>

                            </p>

                            <p class="book-meta">
                                Stock: <?php echo e($book->stock); ?>

                            </p>

                            <div class="mt-5">
                                <a href="<?php echo e(route('books.show', $book->slug)); ?>" class="nav-action-primary">
                                    View Details
                                </a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <div class="pt-2">
                <?php echo e($books->links()); ?>

            </div>
        <?php else: ?>
            <div class="empty-state-card">
                <h3 class="empty-state-title">No books found</h3>
                <p class="empty-state-text">
                    Try changing the selected category or reset the filter.
                </p>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views/catalog/index.blade.php ENDPATH**/ ?>