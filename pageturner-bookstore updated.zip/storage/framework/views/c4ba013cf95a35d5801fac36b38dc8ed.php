<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #1f2937; }
        h1 { font-size: 18px; margin-bottom: 12px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #d1d5db; padding: 8px; text-align: left; }
        th { background: #f3f4f6; }
    </style>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Tier</th>
                <th>Phone</th>
                <th>Location</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td>
                        <?php if($redactPii): ?>
                            <?php echo e(substr($user->email, 0, 1)); ?>***{{ explode('@', $user->email)[1] ?? '' }}
                        <?php else: ?>
                            <?php echo e($user->email); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e(ucfirst($user->role)); ?></td>
                    <td><?php echo e(ucfirst($user->subscription_tier)); ?></td>
                    <td><?php echo e($redactPii ? '***' : $user->phone); ?></td>
                    <td><?php echo e(collect([$user->default_city, $user->default_province, $user->default_country])->filter()->implode(', ')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\exports\users-pdf.blade.php ENDPATH**/ ?>