<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                Orders
            </h2>
            <p class="mt-1 text-sm text-ink-500">
                Review customer orders, totals, and payment progress.
            </p>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(session('success')): ?>
            <div class="soft-alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <section class="admin-panel">
            <?php if($orders->count()): ?>
                <div class="ui-table-wrap">
                    <table class="ui-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Total</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $status = strtolower($order->status);
                                    $statusClass = match($status) {
                                        'pending' => 'status-pill status-pill-pending',
                                        'completed' => 'status-pill status-pill-completed',
                                        default => 'status-pill status-pill-default',
                                    };

                                    $payment = strtolower($order->payment_status);
                                    $paymentClass = match($payment) {
                                        'paid' => 'status-pill status-pill-completed',
                                        'pending', 'unpaid' => 'status-pill status-pill-pending',
                                        default => 'status-pill status-pill-default',
                                    };
                                ?>
                                <tr>
                                    <td class="font-semibold text-ink-900"><?php echo e($order->order_number); ?></td>
                                    <td><?php echo e($order->user?->email); ?></td>
                                    <td><span class="<?php echo e($statusClass); ?>"><?php echo e(ucfirst($order->status)); ?></span></td>
                                    <td><span class="<?php echo e($paymentClass); ?>"><?php echo e(ucfirst($order->payment_status)); ?></span></td>
                                    <td>₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></td>
                                    <td><?php echo e($order->created_at->format('M d, Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="nav-action-primary">
                                            View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <div class="mt-5">
                        <?php echo e($orders->links()); ?>

                    </div>
                </div>
            <?php else: ?>
                <p class="text-sm text-ink-500">No orders found.</p>
            <?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\admin\orders\index.blade.php ENDPATH**/ ?>