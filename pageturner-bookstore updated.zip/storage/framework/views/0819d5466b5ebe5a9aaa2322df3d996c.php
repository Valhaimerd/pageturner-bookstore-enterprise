<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    Receipt
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    Printable receipt for this order.
                </p>
            </div>

            <div class="flex flex-wrap gap-2">
                <button onclick="window.print()" class="nav-action-primary">
                    Print
                </button>

                <a href="<?php echo e(route('orders.show', $order)); ?>" class="nav-action-secondary">
                    Back
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="max-w-4xl mx-auto">
        <section class="receipt-card space-y-6">
            <div class="receipt-brand">
                <p class="receipt-brand-title">Page<span class="brand-highlight">Turner</span></p>
                <p class="receipt-brand-subtitle">Official Receipt</p>
            </div>

            <div class="receipt-divider"></div>

            <div class="receipt-meta-grid">
                <p><strong>Receipt #:</strong> <?php echo e($order->receipt_number); ?></p>
                <p><strong>Order #:</strong> <?php echo e($order->order_number); ?></p>
                <p><strong>Date:</strong> <?php echo e($order->created_at->format('M d, Y h:i A')); ?></p>
                <p><strong>Status:</strong> <?php echo e(ucfirst($order->status)); ?></p>
            </div>

            <div class="receipt-divider"></div>

            <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div>
                    <p class="receipt-section-title">Billed To</p>
                    <div class="mt-3 detail-list">
                        <p><?php echo e($order->buyer_name); ?></p>
                        <p><?php echo e($order->buyer_email); ?></p>
                        <p><?php echo e($order->buyer_phone ?: '—'); ?></p>
                    </div>
                </div>

                <div>
                    <p class="receipt-section-title">Address</p>
                    <div class="mt-3 detail-list">
                        <p><?php echo e($order->address_line_1); ?></p>
                        <?php if($order->address_line_2): ?>
                            <p><?php echo e($order->address_line_2); ?></p>
                        <?php endif; ?>
                        <p><?php echo e($order->city); ?>, <?php echo e($order->province); ?> <?php echo e($order->postal_code); ?></p>
                        <p><?php echo e($order->country); ?></p>
                    </div>
                </div>
            </div>

            <div class="receipt-divider"></div>

            <div class="ui-table-wrap">
                <table class="ui-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Unit</th>
                            <th>Qty</th>
                            <th>Line Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <p class="font-semibold text-ink-900"><?php echo e($item->book_title); ?></p>
                                    <p class="text-sm text-ink-500"><?php echo e($item->book_author); ?></p>
                                </td>
                                <td>₱<?php echo e(number_format((float) $item->unit_price, 2)); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>₱<?php echo e(number_format((float) $item->line_total, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="receipt-total-box space-y-2 text-sm">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>₱<?php echo e(number_format((float) $order->subtotal, 2)); ?></span>
                </div>
                <div class="summary-row">
                    <span>Shipping</span>
                    <span>₱<?php echo e(number_format((float) $order->shipping_fee, 2)); ?></span>
                </div>
                <div class="summary-row">
                    <span>Tax</span>
                    <span>₱<?php echo e(number_format((float) $order->tax_amount, 2)); ?></span>
                </div>
                <div class="summary-total-row">
                    <span>Total</span>
                    <span>₱<?php echo e(number_format((float) $order->total_amount, 2)); ?></span>
                </div>
            </div>

            <p class="text-center text-xs text-ink-500">
                This is a system-generated receipt.
            </p>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\orders\receipt.blade.php ENDPATH**/ ?>