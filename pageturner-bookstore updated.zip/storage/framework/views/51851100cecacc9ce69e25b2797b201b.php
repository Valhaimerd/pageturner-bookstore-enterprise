<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-2xl font-bold tracking-tight text-ink-900 leading-tight">
                    Notifications
                </h2>
                <p class="mt-1 text-sm text-ink-500">
                    Review system updates, order changes, and activity alerts.
                </p>
            </div>

            <form method="POST" action="<?php echo e(route('notifications.read_all')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="nav-action-secondary">
                    Mark All Read
                </button>
            </form>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="space-y-6">
        <?php if(session('success')): ?>
            <div class="soft-alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <section class="content-card">
            <?php if($notifications->count()): ?>
                <div class="notification-list">
                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="notification-card <?php echo e(is_null($notification->read_at) ? 'notification-card-unread' : ''); ?>">
                            <div class="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                                <div class="flex-1">
                                    <p class="notification-title">
                                        <?php echo e($notification->data['message'] ?? 'Notification'); ?>

                                    </p>

                                    <div class="mt-2 space-y-1">
                                        <?php if(isset($notification->data['order_number'])): ?>
                                            <p class="notification-meta">Order #: <?php echo e($notification->data['order_number']); ?></p>
                                        <?php endif; ?>

                                        <?php if(isset($notification->data['receipt_number'])): ?>
                                            <p class="notification-meta">Receipt #: <?php echo e($notification->data['receipt_number']); ?></p>
                                        <?php endif; ?>

                                        <?php if(isset($notification->data['status'])): ?>
                                            <p class="notification-meta">Status: <?php echo e(ucfirst($notification->data['status'])); ?></p>
                                        <?php endif; ?>

                                        <?php if(isset($notification->data['payment_status'])): ?>
                                            <p class="notification-meta">Payment: <?php echo e(ucfirst($notification->data['payment_status'])); ?></p>
                                        <?php endif; ?>

                                        <?php if(isset($notification->data['customer_email'])): ?>
                                            <p class="notification-meta">Customer: <?php echo e($notification->data['customer_email']); ?></p>
                                        <?php endif; ?>

                                        <?php if(isset($notification->data['rating'])): ?>
                                            <p class="notification-meta">Rating: <?php echo e($notification->data['rating']); ?>/5</p>
                                        <?php endif; ?>
                                    </div>

                                    <p class="notification-time">
                                        <?php echo e($notification->created_at->format('M d, Y h:i A')); ?>

                                    </p>
                                </div>

                                <?php if(is_null($notification->read_at)): ?>
                                    <form method="POST" action="<?php echo e(route('notifications.read', $notification->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="nav-action-primary">
                                            Mark Read
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-6">
                    <?php echo e($notifications->links()); ?>

                </div>
            <?php else: ?>
                <div class="empty-state-card !shadow-none !border-0 !p-0">
                    <h3 class="empty-state-title">No notifications yet</h3>
                    <p class="empty-state-text">
                        Notifications will appear here when there are updates to your account or orders.
                    </p>
                </div>
            <?php endif; ?>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\notifications\index.blade.php ENDPATH**/ ?>