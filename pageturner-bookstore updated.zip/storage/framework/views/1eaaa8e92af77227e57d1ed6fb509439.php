<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn-primary-ui'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views/components/primary-button.blade.php ENDPATH**/ ?>