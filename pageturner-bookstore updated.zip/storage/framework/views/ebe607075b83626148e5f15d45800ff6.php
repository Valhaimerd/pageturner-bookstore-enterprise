<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn-secondary-ui'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\USEmbassy\Desktop\pageturner-bookstore\resources\views\components\secondary-button.blade.php ENDPATH**/ ?>