<?php

use App\Http\Controllers\Api\BookController;
use App\Http\Controllers\Api\OrderController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')
    ->name('api.')
    ->group(function () {
        Route::middleware(['api.track', 'throttle:public-api', 'api.transform.request', 'api.transform.response'])
            ->group(function () {
                Route::get('/books', [BookController::class, 'index'])->name('books.index');
                Route::get('/books/{book:slug}', [BookController::class, 'show'])->name('books.show');
            });

        Route::middleware(['auth', 'api.track', 'throttle:auth-api', 'api.transform.request', 'api.transform.response'])
            ->group(function () {
                Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
                Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
            });
    });
